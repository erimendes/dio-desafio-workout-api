# 🏋️‍♂️ DIO Desafio - Workout API

API construída com **FastAPI**, **SQLAlchemy** e **PostgreSQL**.

## 🚀 Rodando com Docker

```bash
make up
```

Acesse: [http://localhost:8000/docs](http://localhost:8000/docs)
